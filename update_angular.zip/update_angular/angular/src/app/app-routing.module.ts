import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashbordComponent } from './dashbord/dashbord.component';
import { ManageDataComponent } from './manage-data/manage-data.component';
import { EmpInsertComponent } from './emp-insert/emp-insert.component';


const routes: Routes = [
  { path: '', component: LoginComponent},
  { path: 'dashbord', component: DashbordComponent},
  { path: 'manageData', component: ManageDataComponent},
  { path: 'empInsert', component: EmpInsertComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
