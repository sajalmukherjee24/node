import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HeroService} from '../hero.service';

@Component({
  selector: 'app-dashbord',
  templateUrl: './dashbord.component.html',
  styleUrls: ['./dashbord.component.css']
})
export class DashbordComponent implements OnInit {
public results="";
mymodal=false;
 public check_login=false;
 constructor(public router: Router, private myservies:HeroService) {
  var userDt=JSON.parse(sessionStorage.getItem('userdata'));
// console.log(userDt.new_name);

  this.myservies.showdata(userDt).subscribe(result=>{
    // console.log(this.results);
    if(result){
      // console.log('hii');
      this.results=result;

      // console.log(this.results);
      
    }
    

  });

  }
  

  edit_data(id){
    alert(id);
    console.log(id);
    this.mymodal=true;
    // console.log(this.id.remove());

   
    
  }

  close_modal(){
    // alert();
    this.mymodal=false;
  }
  delete_data(id){
    // console.log(id);
  }

  close_acount(id){
    alert(id);

    var r = confirm("Press a button!");
      if (r == true) {
        // alert('yes');
        let data={
          "update_accout_status_id":id
          }
         console.log(data);

    this.myservies.update_accout_status(data).subscribe(result =>{
      console.log(result);
      if (result) {
        alert("update done");
        sessionStorage.removeItem('userdata');
        this.check_login=false;
        this.router.navigate([''])
        // location.reload();
      }
      
      
    });
      } 
      
    // else {
    //     alert('no');
    // }


    
  }


  ngOnInit() {
    
  }

}
