import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";

import { HeroService} from '../hero.service';
@Component({
  selector: 'app-emp-insert',
  templateUrl: './emp-insert.component.html',
  styleUrls: ['./emp-insert.component.css']
})
export class EmpInsertComponent implements OnInit {
  public name='';
  public age='';
  public salary='';
  public doj='';

  constructor(public router: Router, private myservies:HeroService) { }

  empinsert_fun(){




    let data={
      "name":this.name,
      "age":this.age,
      "salary":this.salary,
      "doj":this.doj
    }

    this.myservies.InsertEmpData(data).subscribe(result =>{
      console.log(result);
      if (result) {
        alert("insert done");
        this.router.navigate(['/manageData']);
      }
      else{
        alert('bye');
      }
    //   this.step_1=true;
    //   this.step_2=false;
      
    });
  }
  ngOnInit() {
  }

}
