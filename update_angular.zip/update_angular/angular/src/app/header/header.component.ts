import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  check_login=false;
  constructor(private router: Router) {
    
    if(sessionStorage.getItem('userdata')){
      var userDt=JSON.parse(sessionStorage.getItem('userdata'));
      if(userDt.id){
        // alert('ok');
      }
      else
      {
        alert('not login');
        this.router.navigate(['']);
      }
    }
    else{
      this.router.navigate(['']);
    }

  }

  logout(){
    // alert();
    sessionStorage.removeItem('userdata');
    this.check_login=false;
    this.router.navigate([''])
  }
  
  ngOnInit() {
  }

}
