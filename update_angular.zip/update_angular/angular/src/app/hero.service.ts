import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import {map} from 'rxjs/operators';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class HeroService {
  

  constructor(private http: Http) { }

  getLogin(logdt){
    // console.log(logdt);

    return this.http.post(environment.nodAPI+'getLogin',logdt).pipe(map(res=>res.json()));
  }


  getInsert(insertdata){
    // console.log(logdt);

    return this.http.post(environment.nodAPI+'getInsert',insertdata).pipe(map(res=>res.json()));
  }
  InsertEmpData(data_new){
    return this.http.post(environment.nodAPI+'InsertEmpData',data_new).pipe(map(res=>res.json()));

  }
  
  showdata(userDt){
    // console.log(logdt);

    return this.http.post(environment.nodAPI+'showData',userDt).pipe(map(res=>res.json()));
  }
  login_info(userDt){
    return this.http.post(environment.nodAPI+'login_info',userDt).pipe(map(res=>res.json()));
  }
  showEmpdata(){
    // console.log(logdt);

    return this.http.post(environment.nodAPI+'showEmpdata','').pipe(map(res=>res.json()));
  }
  update_status(status_data){
    // console.log("hiiii");
    return this.http.post(environment.nodAPI+'update_status',status_data).pipe(map(res=>res.json()));
  }
  UpdateEmpData(data){
    // console.log(data);
    return this.http.post(environment.nodAPI+'update_emp_data',data).pipe(map(res=>res.json()));
    
  }
  update_accout_status(acount_data){
    console.log(acount_data);
    
    return this.http.post(environment.nodAPI+'update_accout_status',acount_data).pipe(map(res=>res.json()));
  }
}
