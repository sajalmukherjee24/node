import {
    Component,
    OnInit
} from '@angular/core';
import {
    Router
} from "@angular/router";

import {
    HeroService
} from '../hero.service';


@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

    public username = '';
    public password = '';
    public re_pass = '';
    public new_name = '';
    public email = '';
    public ph_no = '';
    public adds = '';

    step_1 = true;
    step_2 = false;

    // public username_req=false;
    // public password_req=false;




    constructor(public router: Router, private myservies: HeroService) {}



    logincheck() {

      if (this.username == "" || this.password == "") {
          alert('this fild is req');
          // this.username_req=true;
          // this.password_req=true;
      } 
      else {
          let data = {
              "username": this.username,
              "password": this.password
          }
          this.myservies.getLogin(data).subscribe(result => {
              console.log(result[0]);
  
              if (!result[0]) {
                  console.log('bye');
                  alert('incorrect user details');
  
              } else if (result[0].status == "deactive") {
                  console.log('deactive');
                  alert('acount is closed');
                  this.router.navigate(['']);
              }
               
              else{
  
                console.log('good login');
                alert('login done');
  
                var convert_string=JSON.stringify(result[0]);
                sessionStorage.setItem('userdata',convert_string);
                // this.router.navigate(['/']);
                // this.router.navigate(['/']);
                this.router.navigate(['/dashbord']);
  
                console.log(convert_string);
  
              }
  
          });
  
          // console.log(data);
  
      }
  
  
  
    }

    new_insert() {
        if (this.username.length == 0 || this.password.length == 0) {
            alert('pls fill up data');
        } else {
            this.step_1 = false;
            this.step_2 = true;
        }
    }

    new_insert_submit() {

        if (this.re_pass.length == 0 || this.new_name.length == 0) {
            alert('pls fill up data');

        } else if (this.password != this.re_pass) {
            alert('password not match');
        } else {

            let new_data = {
                "username": this.username,
                "password": this.password,
                "re_pass": this.re_pass,
                "new_name": this.new_name,
                "email": this.email,
                "ph_no": this.ph_no,
                "adds": this.adds
            }
            console.log(new_data);
            
            this.myservies.getInsert(new_data).subscribe(result => {
                console.log(result);
                this.step_1 = true;
                this.step_2 = false;
                alert('record insert');

            });




        }
    }



    ngOnInit() {}

}