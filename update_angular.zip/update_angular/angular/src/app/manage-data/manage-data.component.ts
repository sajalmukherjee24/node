import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HeroService} from '../hero.service';


@Component({
  selector: 'app-manage-data',
  templateUrl: './manage-data.component.html',
  styleUrls: ['./manage-data.component.css']
})
export class ManageDataComponent implements OnInit {
  public results="";
  public update_change_status="";


  public name='';
  public age='';
  public salary='';
  public doj='';
  public id ="";



  constructor(public router: Router, private myservies:HeroService) {
    this.myservies.showEmpdata().subscribe(result=>{
      if(result){
        this.results=result;
        console.log(this.results);
        
      }
    });
   }

  add_record(){

  this.router.navigate(['/empInsert']);
    
  }

  status_change(status,id){
    // alert(status);
    // alert(id);
    if (status=="active") {
      this.update_change_status="deactive";
    }
    else{
      this.update_change_status="active";
    }
    let data={
      "status_change_log":status,
      "update_change_status":this.update_change_status,
      "status_id":id
    }
    // let data={
    //   "status_change_log":status,
    //   "status_id":id
    // }
    console.log(data);

    this.myservies.update_status(data).subscribe(result =>{
      console.log(result);
      if (result) {
        alert("update done");
       
        location.reload();

        // for (var key in data) {
        //   if (data.hasOwnProperty(key)) {
        //     var val = data[key];
        //     // val="hi";
        //     console.log(val);
        //   }
        // }


        
       




      }
      
      
    });




  }
  edit_data(item){
    // console.log(item);

    this.name=item.name;
    this.age=item.age;
    this.salary=item.salary;
    this.doj=item.doj;
    this.id = item.id;
  

    
    console.log(item);
    
    
  }

  emp_update_fun(){
    // alert(this.id);
    // console.log(this.id);
    
    let data={
      "name":this.name,
      "age":this.age,
      "salary":this.salary,
      "doj":this.doj,
      "id":this.id
    }
    // console.log(data);

    this.myservies.UpdateEmpData(data).subscribe(result =>{
      console.log(result);
      if (result) {
        alert("insert done");
        this.myservies.showEmpdata().subscribe(result=>{
          if(result){
            this.results=result;
            console.log(this.results);
            
          }
        });
       
      }
      else{
        alert('bye');
      }
    //   this.step_1=true;
    //   this.step_2=false;
      
    });

    
  }


  ngOnInit() {
  }

}
