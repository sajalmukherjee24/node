export const environment = {
  production: true,
  nodAPI:'http://localhost:3000/'

};
