var express = require('express');

var database = require('./config_test/database');
var router = express.Router();


router.post('/', function(req, res, next) {
//   database.query("SELECT * FROM `logindata` WHERE  `username`='"+req.body.username+"' AND password='"+req.body.password+"' ", function (err, result, fields) {
    // database.query("SELECT * FROM `logindata`", function (err, result, fields) {
    // database.query("INSERT INTO `emp_data`(`name`, `adds`,`ph_no`) VALUES ('"+req.body.name+"','"+req.body.adds+"','"+req.body.ph_no+"');", function (err, result, fields) {
        database.query("INSERT INTO `emp_data`(`name`,`age`,`salary`,`doj`) VALUES ('"+req.body.name+"','"+req.body.age+"','"+req.body.salary+"','"+req.body.doj+"')", function (err, result, fields) {

    if (err) 
    {
      console.log('error');
    }
    else
    // console.log(result);
    // res.json({'userame':req.body.username,'pass':req.body});
    res.json(result);
    
  });
});




module.exports = router;

