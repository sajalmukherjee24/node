var express = require('express');

var database = require('./config_test/database');
var router = express.Router();

/* GET users listing. */
// router.post('/', function(req, res, next) {
//   // res.send('respond with a resource');
//   database.query("INSERT INTO emp_data (name,adds,ph_no) VALUES ('"+req.body.name+"','"+req.body.adds+"','"+req.body.ph_no+"')", function (err, result, fields) {
//     if (err) 
//     {
//       console.log('error');
//     }
//     else
//     // console.log(result);
//     res.json(result);
//   });
// });

router.post('/', function(req, res, next) {
  database.query("SELECT * FROM `logindata` WHERE  `username`='"+req.body.username+"' AND password='"+req.body.password+"' ", function (err, result, fields) {
    // database.query("SELECT * FROM `logindata`", function (err, result, fields) {
//   database.query("INSERT INTO `logindata`(`username`, `password`,`re_pass`, `new_name`) VALUES ('"+req.body.username+"','"+req.body.password+"','"+req.body.username+"','"+req.body.username+"');", function (err, result, fields) {
    if (err) 
    {
      console.log('error');
    }
    else
    console.log(result);
    // res.json({'userame':req.body.username,'pass':req.body});
    res.json(result);
    
  });
});




module.exports = router;

