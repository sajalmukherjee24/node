var express = require('express');

var database = require('./config_test/database');
var router = express.Router();


router.post('/', function(req, res, next) {
  database.query("SELECT * FROM `logindata` WHERE  `username`='"+req.body.username+"' AND password='"+req.body.password+"' ", function (err, result, fields) {
    // database.query("SELECT * FROM `logindata`", function (err, result, fields) {
    if (err) 
    {
      console.log('error');
    }
    else
    // console.log(result);
    // res.json({'userame':req.body.username,'pass':req.body});
    res.json(result);
    
  });
});




module.exports = router;

