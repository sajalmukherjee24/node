var express = require('express');

var database = require('./config_test/database');
var router = express.Router();


router.post('/', function(req, res, next) {
  // database.query("INSERT INTO `logindata`(`username`, `password`,`re_pass`, `new_name`,`email`,`ph_no`,`adds`) VALUES ('"+req.body.username+"','"+req.body.password+"','"+req.body.re_pass+"','"+req.body.new_name+"');", function (err, result, fields) {
  database.query("UPDATE `emp_data` SET `name`='"+req.body.name+"',`age`='"+req.body.age+"',`doj`='"+req.body.doj+"',`salary`='"+req.body.salary	+"' WHERE `id`='"+req.body.id+"'", function (err, result, fields) {

    if (err) 
    {
      console.log('error');
    }
    else
    console.log(result);
    // res.json({'userame':req.body.username,'pass':req.body});
    res.json(result);
    
  });
});




module.exports = router;

