var express = require('express');

var database = require('./config_test/database');
var router = express.Router();

/* GET users listing. */
// router.post('/', function(req, res, next) {
//   // res.send('respond with a resource');
//   database.query("INSERT INTO emp_data (name,adds,ph_no) VALUES ('"+req.body.name+"','"+req.body.adds+"','"+req.body.ph_no+"')", function (err, result, fields) {
//     if (err) 
//     {
//       console.log('error');
//     }
//     else
//     // console.log(result);
//     res.json(result);
//   });
// });

router.post('/', function(req, res, next) {
  // res.send('respond with a resource');
  // var sql = "UPDATE emp_data SET name = '"+req.body.name+"' WHERE id = 6";
  database.query("UPDATE emp_data SET name='"+req.body.name+"' WHERE id=10", function (err, result, fields) {
    if (err) 
    {
      console.log('error');
    }
    else
    // console.log(result);
    res.json(result);
  });
});




module.exports = router;

