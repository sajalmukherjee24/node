-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 03, 2019 at 02:56 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mynode`
--
CREATE DATABASE IF NOT EXISTS `mynode` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `mynode`;

-- --------------------------------------------------------

--
-- Table structure for table `emp_data`
--

DROP TABLE IF EXISTS `emp_data`;
CREATE TABLE IF NOT EXISTS `emp_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `age` varchar(500) NOT NULL,
  `salary` varchar(500) NOT NULL,
  `doj` date NOT NULL DEFAULT current_timestamp(),
  `status` enum('active','deactive') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_data`
--

INSERT INTO `emp_data` (`id`, `name`, `age`, `salary`, `doj`, `status`) VALUES
(24, 'asdasd', 'sdfsdf', 'sdfsdf', '2019-09-30', 'deactive'),
(25, 'sdsdsfd', 'fsdfsd', 'sdfsdfdsf', '2019-09-17', 'active'),
(26, 'asdsadada', 'dfgdfg', 'dfgdfg', '2019-10-09', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `logindata`
--

DROP TABLE IF EXISTS `logindata`;
CREATE TABLE IF NOT EXISTS `logindata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL,
  `re_pass` varchar(500) NOT NULL,
  `new_name` varchar(500) NOT NULL,
  `email` varchar(300) NOT NULL,
  `ph_no` varchar(300) NOT NULL,
  `adds` varchar(300) NOT NULL,
  `status` enum('active','deactive') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logindata`
--

INSERT INTO `logindata` (`id`, `username`, `password`, `re_pass`, `new_name`, `email`, `ph_no`, `adds`, `status`) VALUES
(19, 'admin', '123', '123', 'admin', 'admin@gmail.com', '123', '1223', 'active'),
(22, 'admin', '412', '412', '412', 'sajalmukherjee2408@gmail.com', '412', '412', 'active');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
